/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import ProductCategories from "./components/ProductCategories";
import Services from "./components/Services";
import Gallery from "./components/Gallery";
import About from "./components/About";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";
import RegistrationForm from "./components/RegistrationForm";
import { Toaster } from "sonner";
import { Pill, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans selection:bg-primary/10 selection:text-primary">
      <Navbar />
      
      <main>
        <Hero />
        <ProductCategories />
        <Services />
        <Gallery />
        <About />

        {/* Final CTA Section */}
        <section className="py-32 px-6 bg-slate-50">
          <div className="max-w-6xl mx-auto bg-slate-900 rounded-[64px] p-12 lg:p-24 text-center relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(15,23,42,0.3)]">
            {/* Decorative elements */}
            <div className="absolute -top-24 -left-24 w-96 h-96 bg-primary/20 rounded-full blur-[120px]" />
            <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
            
            <div className="relative z-10">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 backdrop-blur-xl rounded-3xl mb-10 border border-white/10">
                <Pill className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-5xl lg:text-7xl font-black text-white mb-8 tracking-tighter leading-[0.9]">
                ¿Listo para optimizar su <span className="text-primary">cadena de suministro?</span>
              </h2>
              <p className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto font-medium leading-relaxed">
                Únase a nuestra red de distribución y experimente la eficiencia y seguridad 
                que su negocio farmacéutico necesita hoy mismo.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <RegistrationForm>
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white rounded-2xl px-12 h-16 text-sm font-black uppercase tracking-widest shadow-2xl shadow-primary/30">
                    Registrarse Ahora
                    <ArrowRight className="ml-3 w-5 h-5" />
                  </Button>
                </RegistrationForm>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
      <Toaster position="top-center" richColors />
    </div>
  );
}
