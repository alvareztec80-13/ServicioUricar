import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2, Send } from "lucide-react";

const formSchema = z.object({
  nombre: z.string().min(2, {
    message: "El nombre debe tener al menos 2 caracteres.",
  }),
  email: z.string().email({
    message: "Por favor, introduce un correo electrónico válido.",
  }),
  telefono: z.string().min(10, {
    message: "El teléfono debe tener al menos 10 dígitos.",
  }),
  requerimientos: z.string().min(10, {
    message: "Por favor, describe tus requerimientos (mínimo 10 caracteres).",
  }),
});

interface RegistrationFormProps {
  children: React.ReactNode;
}

export default function RegistrationForm({ children }: RegistrationFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nombre: "",
      email: "",
      telefono: "",
      requerimientos: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    try {
      // Simulamos el envío de correo. 
      // En un entorno real, esto llamaría a una API (como Formspree, EmailJS o un backend propio)
      console.log("Enviando datos a ventas@ismalu.com.mx:", values);
      
      // Simulamos delay de red
      await new Promise((resolve) => setTimeout(resolve, 1500));

      toast.success("¡Registro enviado con éxito!", {
        description: "Nos pondremos en contacto contigo a la brevedad.",
      });
      
      form.reset();
      setIsOpen(false);
    } catch (error) {
      toast.error("Error al enviar el registro", {
        description: "Por favor, inténtalo de nuevo más tarde.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] rounded-[32px] border-slate-100 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-3xl font-black tracking-tighter text-slate-900">Registro de Cliente</DialogTitle>
          <DialogDescription className="text-slate-500 font-medium">
            Completa el formulario para enviarnos tus requerimientos a <span className="text-primary font-bold">ventas@ismalu.com.mx</span>
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 pt-4">
            <FormField
              control={form.control}
              name="nombre"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-black uppercase tracking-widest text-slate-500">Nombre Completo</FormLabel>
                  <FormControl>
                    <Input placeholder="Juan Pérez" {...field} className="rounded-2xl border-slate-100 bg-slate-50/50 h-12 font-medium focus-visible:ring-primary" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs font-black uppercase tracking-widest text-slate-500">Correo Electrónico</FormLabel>
                    <FormControl>
                      <Input placeholder="juan@ejemplo.com" {...field} className="rounded-2xl border-slate-100 bg-slate-50/50 h-12 font-medium focus-visible:ring-primary" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="telefono"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs font-black uppercase tracking-widest text-slate-500">Teléfono</FormLabel>
                    <FormControl>
                      <Input placeholder="55 1234 5678" {...field} className="rounded-2xl border-slate-100 bg-slate-50/50 h-12 font-medium focus-visible:ring-primary" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="requerimientos"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-black uppercase tracking-widest text-slate-500">Requerimientos / Mensaje</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe los medicamentos o insumos que necesitas..." 
                      className="rounded-2xl border-slate-100 bg-slate-50/50 min-h-[120px] font-medium focus-visible:ring-primary resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-primary/20"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-5 w-5" />
                  Enviar Registro
                </>
              )}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
