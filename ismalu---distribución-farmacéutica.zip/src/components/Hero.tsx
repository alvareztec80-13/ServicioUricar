import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck } from "lucide-react";
import RegistrationForm from "./RegistrationForm";

export default function Hero() {
  return (
    <section id="inicio" className="relative pt-48 pb-24 overflow-hidden bg-slate-50">
      {/* Background Accents */}
      <div className="absolute top-0 right-0 -z-10 w-1/2 h-full bg-primary/5 rounded-l-[200px] hidden lg:block" />
      <div className="absolute top-40 left-20 -z-10 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-white border border-slate-200 shadow-sm text-primary text-[10px] font-black uppercase tracking-[0.2em] mb-8">
            <ShieldCheck className="w-4 h-4" />
            Certificación Sanitaria Federal
          </div>
          <h1 className="text-6xl lg:text-8xl font-black text-slate-900 leading-[0.9] mb-8 tracking-tighter">
            Distribución de <span className="text-primary">Patente y Genéricos</span>
          </h1>
          <p className="text-xl text-slate-600 mb-10 max-w-lg leading-relaxed font-medium">
            Suministro farmacéutico de alta especialidad con logística certificada. 
            Garantizamos la cadena de frío y la integridad de cada fármaco.
          </p>
          <div className="flex flex-col sm:flex-row gap-5">
            <RegistrationForm>
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white rounded-2xl px-10 h-16 text-sm font-black uppercase tracking-widest shadow-2xl shadow-primary/30">
                Iniciar Registro
                <ArrowRight className="ml-3 w-5 h-5" />
              </Button>
            </RegistrationForm>
            <Button size="lg" variant="outline" className="rounded-2xl px-10 h-16 text-sm font-black uppercase tracking-widest border-slate-200 text-slate-700 hover:bg-white">
              Ver Catálogo
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-3 gap-8 border-t border-slate-200 pt-10">
            <div>
              <div className="text-3xl font-black text-slate-900 mb-1 tracking-tighter">10+</div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Años de Trayectoria</div>
            </div>
            <div>
              <div className="text-3xl font-black text-slate-900 mb-1 tracking-tighter">150+</div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Puntos de Entrega</div>
            </div>
            <div>
              <div className="text-3xl font-black text-slate-900 mb-1 tracking-tighter">24/7</div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Monitoreo Activo</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1, ease: "circOut" }}
          className="relative"
        >
          <div className="relative z-10 rounded-[40px] overflow-hidden shadow-[0_50px_100px_-20px_rgba(15,23,42,0.25)] border-[12px] border-white">
            <img
              src="https://images.unsplash.com/photo-1587854692152-cbe660dbbb88?q=80&w=2069&auto=format&fit=crop"
              alt="Logística Farmacéutica"
              className="w-full h-[600px] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Floating Badge */}
          <div className="absolute -bottom-10 -right-10 z-20 bg-white p-8 rounded-[32px] shadow-2xl border border-slate-100 max-w-[240px] animate-bounce-slow">
            <div className="flex items-center gap-4 mb-3">
              <div className="bg-emerald-500 w-3 h-3 rounded-full animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Estado de Red</span>
            </div>
            <div className="text-lg font-black text-slate-900 leading-tight">Distribución Nacional Operativa</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
