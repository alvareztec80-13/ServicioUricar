import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Phone, Pill, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import RegistrationForm from "./RegistrationForm";

const navLinks = [
  { name: "Inicio", href: "#inicio" },
  { name: "Productos", href: "#productos" },
  { name: "Servicios", href: "#servicios" },
  { name: "Sobre Nosotros", href: "#nosotros" },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Top Bar - Hidden on scroll for focus */}
      <div className={cn(
        "bg-primary text-primary-foreground py-2 px-6 transition-all duration-300 overflow-hidden",
        isScrolled ? "h-0 opacity-0" : "h-auto opacity-100"
      )}>
        <div className="max-w-7xl mx-auto flex justify-between items-center text-[10px] uppercase tracking-widest font-bold">
          <div className="flex gap-6">
            <span className="flex items-center gap-2"><MapPin className="w-3 h-3" /> CDMX, México</span>
            <span className="flex items-center gap-2"><Mail className="w-3 h-3" /> contacto@ismalu.com.mx</span>
          </div>
          <div className="flex gap-4">
            <span>Lun - Vie: 09:00 - 19:00</span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav
        className={cn(
          "transition-all duration-500 px-6",
          isScrolled
            ? "py-3 bg-white/90 backdrop-blur-xl border-b border-slate-200/50 shadow-sm"
            : "py-6 bg-transparent"
        )}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo Section */}
          <div className="flex items-center gap-3 group cursor-pointer">
            <div className="bg-primary p-2.5 rounded-2xl shadow-lg shadow-primary/20 group-hover:rotate-12 transition-transform duration-500">
              <Pill className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tighter text-slate-900 leading-none">
                ISMALU
              </span>
              <span className="text-[8px] font-bold text-primary tracking-[0.2em] uppercase mt-1">
                Farmacéutica
              </span>
            </div>
          </div>

          {/* Desktop Navigation - Centered */}
          <div className="hidden md:flex items-center bg-slate-100/50 rounded-full px-2 py-1 border border-slate-200/50">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-6 py-2 text-xs font-bold uppercase tracking-widest text-slate-600 hover:text-primary hover:bg-white rounded-full transition-all duration-300"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-slate-600 font-bold text-xs uppercase tracking-wider" asChild>
              <a href="https://wa.me/525561455848" target="_blank" rel="noreferrer">
                <Phone className="w-4 h-4 mr-2 text-primary" />
                Contacto
              </a>
            </Button>
            <RegistrationForm>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full px-6 font-bold text-xs uppercase tracking-widest shadow-lg shadow-primary/20">
                Registro
              </Button>
            </RegistrationForm>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-slate-900 bg-slate-100 rounded-xl"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="absolute top-full left-0 right-0 bg-white border-b border-slate-200 overflow-hidden md:hidden shadow-2xl"
            >
              <div className="p-8 flex flex-col gap-6">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-2xl font-black text-slate-900 hover:text-primary transition-colors"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.name}
                  </a>
                ))}
                <div className="h-px bg-slate-100 w-full" />
                <div className="flex flex-col gap-4">
                  <Button variant="outline" className="w-full h-14 rounded-2xl justify-center gap-3 font-bold uppercase tracking-widest text-xs" asChild>
                    <a href="https://wa.me/525561455848" target="_blank" rel="noreferrer">
                      <Phone className="w-5 h-5" />
                      Llamar ahora
                    </a>
                  </Button>
                  <RegistrationForm>
                    <Button className="w-full h-14 rounded-2xl bg-primary hover:bg-primary/90 text-white font-bold uppercase tracking-widest text-xs shadow-xl shadow-primary/20">
                      Registrarse
                    </Button>
                  </RegistrationForm>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}
