import { motion } from "motion/react";
import { Pill, ShieldCheck, Activity, Thermometer, HeartPulse, Stethoscope } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const categories = [
  {
    name: "Medicamentos de Patente",
    description: "Distribución de fármacos innovadores de laboratorios líderes mundiales.",
    icon: Pill,
    items: ["Alta Especialidad", "Oncológicos", "Cardiovasculares"],
    color: "text-blue-600",
    bg: "bg-blue-50",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?q=80&w=2070&auto=format&fit=crop",
  },
  {
    name: "Medicamentos Genéricos",
    description: "Amplio catálogo de genéricos intercambiables con los más altos estándares.",
    icon: Activity,
    items: ["Antibióticos", "Analgesicos", "Antiinflamatorios"],
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    image: "https://images.unsplash.com/photo-1471864190281-ad5f9f81ce8a?q=80&w=2070&auto=format&fit=crop",
  },
  {
    name: "Insumos Médicos",
    description: "Material de curación y equipo médico esencial para clínicas y hospitales.",
    icon: Stethoscope,
    items: ["Material de Curación", "Equipo de Diagnóstico", "Desechables"],
    color: "text-indigo-600",
    bg: "bg-indigo-50",
    image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?q=80&w=2070&auto=format&fit=crop",
  },
];

export default function ProductCategories() {
  return (
    <section id="productos" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <Badge variant="outline" className="mb-4 border-primary/20 text-primary bg-primary/5 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
              Nuestro Portafolio
            </Badge>
            <h2 className="text-5xl lg:text-6xl font-black text-slate-900 mb-6 tracking-tighter">
              Especialistas en <span className="text-primary">Patente y Genéricos</span>
            </h2>
            <p className="text-xl text-slate-600 font-medium">
              Contamos con una cadena de suministro robusta para asegurar que los medicamentos lleguen 
              en condiciones óptimas a su destino final.
            </p>
          </div>
          <div className="flex gap-4">
            <div className="text-center px-8 py-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
              <div className="text-4xl font-black text-slate-900 tracking-tighter">1000+</div>
              <div className="text-[10px] text-slate-400 uppercase font-black tracking-[0.2em] mt-2">SKUs Activos</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-slate-100 shadow-sm hover:shadow-[0_30px_60px_-15px_rgba(15,23,42,0.1)] transition-all duration-500 group overflow-hidden flex flex-col rounded-[32px]">
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={cat.image} 
                    alt={cat.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent" />
                  <div className={`absolute bottom-6 left-6 w-14 h-14 rounded-2xl bg-white text-primary flex items-center justify-center shadow-2xl group-hover:rotate-12 transition-transform duration-500`}>
                    <cat.icon className="w-7 h-7" />
                  </div>
                </div>
                <CardContent className="p-10 flex-grow">
                  <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight">{cat.name}</h3>
                  <p className="text-slate-600 mb-8 leading-relaxed font-medium">
                    {cat.description}
                  </p>
                  <ul className="space-y-4">
                    {cat.items.map((item) => (
                      <li key={item} className="flex items-center gap-4 text-sm font-bold text-slate-700">
                        <div className="w-5 h-5 rounded-full bg-emerald-50 flex items-center justify-center">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                        </div>
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
