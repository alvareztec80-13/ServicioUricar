import { motion } from "motion/react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Truck, ShieldCheck, Clock, BarChart3, Package, Globe } from "lucide-react";

const services = [
  {
    title: "Distribución Rápida",
    description: "Garantizamos la entrega oportuna de productos farmacéuticos con nuestra red optimizada.",
    icon: Clock,
    color: "bg-blue-50 text-blue-600",
  },
  {
    title: "Logística Segura",
    description: "Procesos rigurosos para asegurar la integridad de los medicamentos durante el transporte.",
    icon: ShieldCheck,
    color: "bg-emerald-50 text-emerald-600",
  },
  {
    title: "Red Nacional",
    description: "Cobertura completa en todo el territorio mexicano para llegar a donde más se necesita.",
    icon: Globe,
    color: "bg-indigo-50 text-indigo-600",
  },
  {
    title: "Gestión de Inventarios",
    description: "Tecnología de última generación para el control y seguimiento preciso de existencias.",
    icon: BarChart3,
    color: "bg-amber-50 text-amber-600",
  },
  {
    title: "Medicamentos de Patente",
    description: "Distribución autorizada de las principales marcas farmacéuticas globales.",
    icon: Package,
    color: "bg-purple-50 text-purple-600",
  },
  {
    title: "Genéricos de Calidad",
    description: "Amplia gama de medicamentos genéricos que cumplen con los más altos estándares.",
    icon: Truck,
    color: "bg-rose-50 text-rose-600",
  },
];

export default function Services() {
  return (
    <section id="servicios" className="py-32 bg-slate-900 text-white overflow-hidden relative">
      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-0 left-0 w-96 h-96 bg-primary rounded-full blur-[150px] -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary rounded-full blur-[150px] translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-24">
          <Badge variant="outline" className="mb-6 border-primary/30 text-primary bg-primary/10 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
            Excelencia Logística
          </Badge>
          <h3 className="text-5xl lg:text-6xl font-black mb-8 tracking-tighter">Soluciones de Suministro</h3>
          <p className="text-xl text-slate-400 font-medium leading-relaxed">
            Optimizamos la cadena de suministro en el sector salud, asegurando la disponibilidad 
            de medicamentos y productos farmacéuticos con precisión quirúrgica.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-500 h-full group rounded-[32px] p-2">
                <CardHeader className="p-8">
                  <div className={`w-16 h-16 rounded-2xl bg-primary text-white flex items-center justify-center mb-8 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500 shadow-2xl shadow-primary/20`}>
                    <service.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-2xl font-black tracking-tight text-white mb-4">{service.title}</CardTitle>
                  <CardDescription className="text-slate-400 text-lg font-medium leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
