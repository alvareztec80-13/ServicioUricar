import { motion } from "motion/react";
import { CheckCircle2 } from "lucide-react";

export default function About() {
  return (
    <section id="nosotros" className="py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1563213126-a4273aed2016?q=80&w=2070&auto=format&fit=crop"
                alt="Equipo Ismalu"
                className="w-full h-[600px] object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative background shape */}
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-blue-600 rounded-full -z-10 opacity-10" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Sobre Nosotros</h2>
            <h3 className="text-4xl font-bold text-slate-900 mb-8">Compromiso con la Salud de los Mexicanos</h3>
            
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Somos una empresa mexicana dedicada a la comercialización y distribución de productos farmacéuticos. 
              Con más de 10 años de experiencia, implementamos altos estándares de calidad en el manejo, 
              almacenamiento y distribución de cada uno de nuestros productos.
            </p>

            <div className="space-y-8 mb-10">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-900 mb-2">Nuestra Misión</h4>
                  <p className="text-slate-600">
                    Ser parte fundamental de la cadena de suministro, asegurando la calidad de vida de los 
                    mexicanos siendo un eslabón importante para nuestros proveedores y una fortaleza para nuestros clientes.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-900 mb-2">Nuestra Visión</h4>
                  <p className="text-slate-600">
                    Ser una empresa líder a mediano plazo en la comercialización y distribución de medicamentos 
                    e insumos médicos, ofreciendo una amplia gama de productos con gran sentido de responsabilidad.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <div className="text-3xl font-bold text-slate-900 mb-1">100%</div>
                <div className="text-sm text-slate-600 font-medium tracking-tight uppercase">Calidad Garantizada</div>
              </div>
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <div className="text-3xl font-bold text-slate-900 mb-1">24/7</div>
                <div className="text-sm text-slate-600 font-medium tracking-tight uppercase">Soporte Logístico</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
