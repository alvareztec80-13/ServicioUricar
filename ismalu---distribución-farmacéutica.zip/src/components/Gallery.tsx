import { motion } from "motion/react";

const images = [
  {
    url: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2070&auto=format&fit=crop",
    title: "Laboratorio de Calidad",
    category: "Instalaciones",
  },
  {
    url: "https://images.unsplash.com/photo-1586771107445-d3ca888129ff?q=80&w=2072&auto=format&fit=crop",
    title: "Logística Especializada",
    category: "Distribución",
  },
  {
    url: "https://images.unsplash.com/photo-1512069772995-ec65ed45afd6?q=80&w=2077&auto=format&fit=crop",
    title: "Almacenamiento Controlado",
    category: "Seguridad",
  },
  {
    url: "https://images.unsplash.com/photo-1587854692152-cbe660dbbb88?q=80&w=2069&auto=format&fit=crop",
    title: "Suministro Hospitalario",
    category: "Servicios",
  },
  {
    url: "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?q=80&w=1974&auto=format&fit=crop",
    title: "Atención Farmacéutica",
    category: "Clientes",
  },
  {
    url: "https://images.unsplash.com/photo-1585435557343-3b092031a831?q=80&w=2070&auto=format&fit=crop",
    title: "Medicamentos Certificados",
    category: "Productos",
  },
];

export default function Gallery() {
  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-3">Galería Visual</h2>
          <h3 className="text-4xl font-bold text-slate-900 mb-6">Nuestra Operación en Imágenes</h3>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Descubre la infraestructura y el compromiso que respaldan cada una de nuestras entregas 
            de medicamentos en todo el país.
          </p>
        </div>

        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {images.map((image, index) => (
            <motion.div
              key={image.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group rounded-2xl overflow-hidden shadow-lg break-inside-avoid"
            >
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-auto object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-blue-400 text-xs font-bold uppercase tracking-wider mb-1">
                  {image.category}
                </span>
                <h4 className="text-white text-xl font-bold">{image.title}</h4>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
