import { Pill, Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-400 pt-32 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center gap-3 mb-8 group cursor-pointer">
              <div className="bg-primary p-2.5 rounded-2xl shadow-lg shadow-primary/20 group-hover:rotate-12 transition-transform duration-500">
                <Pill className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-black tracking-tighter text-white leading-none">
                  ISMALU
                </span>
                <span className="text-[8px] font-bold text-primary tracking-[0.2em] uppercase mt-1">
                  Farmacéutica
                </span>
              </div>
            </div>
            <p className="text-slate-500 mb-10 leading-relaxed font-medium">
              Especialistas en la distribución y logística de productos farmacéuticos, 
              garantizando un servicio eficiente y seguro en todo México.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">Navegación</h4>
            <ul className="space-y-5">
              <li><a href="#inicio" className="font-bold hover:text-primary transition-colors">Inicio</a></li>
              <li><a href="#productos" className="font-bold hover:text-primary transition-colors">Productos</a></li>
              <li><a href="#servicios" className="font-bold hover:text-primary transition-colors">Servicios</a></li>
              <li><a href="#nosotros" className="font-bold hover:text-primary transition-colors">Sobre Nosotros</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">Contacto Directo</h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">Teléfono</div>
                  <span className="text-white font-bold tracking-tight">(+52) 55 6145 5848</span>
                </div>
              </li>
              <li className="flex gap-4">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">Email</div>
                  <span className="text-white font-bold tracking-tight">contacto@ismalu.com.mx</span>
                </div>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-8">Horario Operativo</h4>
            <div className="bg-white/5 p-8 rounded-[32px] border border-white/5">
              <ul className="space-y-4">
                <li className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider">Lun - Vie</span>
                  <span className="text-white font-black">09:00 - 19:00</span>
                </li>
                <li className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider">Sábados</span>
                  <span className="text-white font-black">09:00 - 13:00</span>
                </li>
                <li className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider">Domingos</span>
                  <span className="text-red-500 font-black">Cerrado</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 text-[10px] font-black uppercase tracking-[0.2em] text-slate-600">
          <p>© 2025 ISMALU. Todos los derechos reservados.</p>
          <div className="flex gap-12">
            <a href="#" className="hover:text-white transition-colors">Aviso de Privacidad</a>
            <a href="#" className="hover:text-white transition-colors">Términos</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
